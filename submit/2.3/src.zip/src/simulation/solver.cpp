#include "solver.h"

#include <Eigen/Core>

using Eigen::Vector3f;

// External Force does not changed.

// Function to calculate the derivative of KineticState
KineticState derivative(const KineticState& state)
{
    return KineticState(state.velocity, state.acceleration, Eigen::Vector3f(0, 0, 0));
}

// Function to perform a single Forward Euler step
KineticState forward_euler_step([[maybe_unused]] const KineticState& previous,
                                const KineticState& current)
{
    // Δt 是时间步长，可以是一个常数，例如 0.01 或者是一个可配置的值
    float delta_time = time_step; // 假设 time_step 已经定义了

    // 根据前向欧拉法，下一个状态的位置是当前位置加上当前速度乘以时间步长
    Eigen::Vector3f next_position = current.position + current.velocity * delta_time;

    // 下一个状态的速度是当前速度加上当前加速度乘以时间步长
    Eigen::Vector3f next_velocity = current.velocity + current.acceleration * delta_time;

    // 返回下一个状态
    return KineticState(next_position, next_velocity, current.acceleration);
}

// Function to perform a single Runge-Kutta step
KineticState runge_kutta_step([[maybe_unused]] const KineticState& previous,
                              const KineticState& current)
{
    return current;
}

// Function to perform a single Backward Euler step
KineticState backward_euler_step([[maybe_unused]] const KineticState& previous,
                                 const KineticState& current)
{
    return current;
}

// Function to perform a single Symplectic Euler step
KineticState symplectic_euler_step(const KineticState& previous, const KineticState& current)
{
    (void)previous;
    return current;
}
